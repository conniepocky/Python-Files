import pygame, sys
from pygame.locals import *

pygame.init()
DISPLAYSURF = pygame.display.set_mode((400, 300))
pygame.display.set_caption('Pygame Example')
pygame.mixer.init()

# Sound and Graphics
playership = pygame.image.load("images/spaceship3.png")
alienship = pygame.image.load("images/spaceship4.png")
explosionsound = pygame.mixer.Sound("sounds/explosion.wav")
lasersound = pygame.mixer.Sound("sounds/laser.wav")

explosiongfx = ([ 0,
                  pygame.image.load("images/explosion1.png"),
                  pygame.image.load("images/explosion2.png"),
                  pygame.image.load("images/explosion3.png"),
                  pygame.image.load("images/explosion4.png"),
                  pygame.image.load("images/explosion3.png"),
                  pygame.image.load("images/explosion2.png"),
                  pygame.image.load("images/explosion1.png")                 
    ])

# Data
alienX = 200
alienY = 10
alienDir = 0
shipX = 200
shipY = 260
laserX = 0
laserY = -30
explosionX = 0
explosionY = 0
explosionFrame = 0

# set up the colours
BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
GREEN = (  0, 255,   0)
BLUE  = (  0,   0, 255)

def drawScreen():
    DISPLAYSURF.fill(BLACK)
    drawAlien()
    drawShip()
    drawLaser()
    drawExplosion()
    pygame.display.update()
    return

def drawExplosion():
    global explosionFrame,alienX,alienY
    x = explosionX
    y = explosionY
    if explosionFrame > 0 :
        DISPLAYSURF.blit(explosiongfx[explosionFrame], (x-15,y))
        explosionFrame = explosionFrame + 1
        if explosionFrame == 8 :
            explosionFrame = 0
            alienY = 10
            alienX = 200
    return

def drawAlien():
    x = alienX
    y = alienY
    DISPLAYSURF.blit(alienship, (x-17,y))
    return

def drawLaser():
    global laserX, laserY
    if laserY >= 1 :
        points = [(laserX,laserY+10),(laserX,laserY)]
        pygame.draw.lines(DISPLAYSURF,WHITE,False,points,1)
    return

def drawShip():
    x = shipX
    y = shipY
    DISPLAYSURF.blit(playership, (x-17,y))
    return

def moveAlien():
    global alienDir, alienX, alienY
    if alienDir == 0:
        alienX = alienX - 1
        if alienX == 0:
            alienDir = 1
    if alienDir == 1:
        alienX = alienX + 1
        if alienX == 400:
            alienDir = 0
    return

def moveLaser():
    global laserY
    if laserY >=1 :
        laserY = laserY - 5
    return

def fireLaser():
    global laserY,laserX
    if laserY <= 0 :
        laserY = shipY
        laserX = shipX
        lasersound.play()
    return

def checkLaser():
    global laserX,laserY,alienX,alienY,explosionFrame,explosionX,explosionY
    if (laserX > alienX-15 and laserX < alienX+15
        and laserY > alienY-15 and laserY < alienY+15) :
        explosionX = alienX
        explosionY = alienY
        alienY = -30
        explosionFrame = 1
        explosionsound.play()
    return

def checkKeys():
    global shipX, shipY
    if pygame.key.get_pressed()[pygame.K_LEFT] !=0 :
        shipX = shipX - 3
    if pygame.key.get_pressed()[pygame.K_RIGHT] !=0 :
        shipX = shipX + 3
    if pygame.key.get_pressed()[pygame.K_SPACE] !=0 :
        fireLaser()
    return




gameclock = pygame.time.Clock()
while True: # main game loop

    # Restrict the speed of the movement
    gameclock.tick(20)
    
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    # Move the alien
    moveAlien()

    # Move the laser
    moveLaser()
        
    # Draw the screen
    drawScreen()

    # Check keyboard input
    checkKeys()
    
    # Check laser collision
    checkLaser()
    

    
    


